package GameElements;

public interface Target {
    public void accept(Ability ability);
}
