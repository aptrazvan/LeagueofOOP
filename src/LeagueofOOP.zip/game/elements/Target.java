package game.elements;

public interface Target {
    void accept(Ability ability);
}
